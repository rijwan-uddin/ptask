import 'package:ptask/models/userList.dart';
import 'package:ptask/repository/member_task_repository.dart';
import 'package:ptask/view/MembersTasks/member_task_interface.dart';
import 'package:ptask/view/MembersTasks/member_task_screen.dart';

class MembersPresenter implements MembersInterface {
  final MembersScreen _view;
  final MemberTaskRepository _repository;

  MembersPresenter(this._view, this._repository);

  @override
  Future<void> fetchUsers(String token) async {
    try {
      // Fetch the user data from the repository
      List<UserList> users = await _repository.fetchUserMembers(
        token: token,  // Use the token passed from the screen
        payload: {'token': token},  // Example payload
      );
      // Pass the fetched data to the screen
      _view.displayUsers(users);
    } catch (e) {
      print('Error fetching users: $e');
    }
  }

  @override
  void displayUsers(List<UserList> users) {
    // Display the users (this will be handled by the view)
    _view.displayUsers(users);
  }
}

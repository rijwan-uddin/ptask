class RouteConstants {
  static const String home = '/home';
}

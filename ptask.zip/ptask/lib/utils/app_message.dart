class AppMessage{
  static const String msgDefaultError = 'something went wrong';
}
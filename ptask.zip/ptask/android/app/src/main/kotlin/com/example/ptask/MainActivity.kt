package com.example.ptask

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
